<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>

<html lang="es">
<head>
    <link rel="icon" type="image/png" href="<?php echo base_url('images/favicon.png')?>">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="A front-end template that helps you build fast, modern mobile web apps.">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sistema IoT HYDROCROP</title>

    <!-- Add to homescreen for Chrome on Android -->
    <meta name="mobile-web-app-capable" content="yes">


    <!-- Add to homescreen for Safari on iOS -->
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="Material Design Lite">


    <!-- Tile icon for Win8 (144x144 + tile color) -->
    <meta name="msapplication-TileImage" content="images/touch/ms-touch-icon-144x144-precomposed.png">
    <meta name="msapplication-TileColor" content="#3372DF">

    <!-- SEO: If your mobile URL is different from the desktop URL, add a canonical link to the desktop page https://developers.google.com/webmasters/smartphone-sites/feature-phones -->
    <!--
    <link rel="canonical" href="http://www.example.com/">
    -->

    <link href='https://fonts.googleapis.com/css?family=Roboto:400,500,300,100,700,900' rel='stylesheet'
          type='text/css'>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!-- inject:css -->
    <link rel="stylesheet" href="<?php echo base_url('css/lib/getmdl-select.min.css')?>">
    <link rel="stylesheet" href="<?php echo base_url('css/lib/nv.d3.min.css')?>">
    <link rel="stylesheet" href="<?php echo base_url('css/application.min.css')?>">
    <link rel="stylesheet" href="<?php echo base_url('css/myStyle.css')?>">     
    <link rel="stylesheet" href="<?php echo base_url('css/bootstrap.css')?>">
    <link rel="stylesheet" href="<?php echo base_url('css/hydrocrop.css')?>">
    <link rel="stylesheet" href="<?php echo base_url('css/sweetalert2.css')?>">    
    
    <!-- endinject -->

</head>
